﻿using System;
using System.Collections;
using ClearBlog.IRepository;
using System.Collections.Generic;
using System.Linq;
using ClearBlog.Models;
using System.Data.Entity;
using PagedList;

namespace ClearBlog.Repository
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private ClearDBEntities db = null;
        private DbSet<T> table = null;

        public GenericRepository()
        {
            this.db = new ClearDBEntities();
            table = db.Set<T>();
        }

        public GenericRepository(ClearDBEntities db)
        {
            this.db = db;
            table = db.Set<T>();
        }

        public IEnumerable<T> SelectAll()
        {
            return table;
        }

        public T SelectById(object id)
        {
            return table.Find(id);
        }

        public void Insert(T obj)
        {
            table.Add(obj);
        }

        public void Update(T obj)
        {
            table.Attach(obj);
            db.Entry(obj).State = EntityState.Modified;
        }

        public void Delete(object id)
        {
            T existing = table.Find(id);
            table.Remove(existing);
        }

        public void Save()
        {
            db.SaveChanges();
        }

        public void Dispose()
        {
            db.Dispose();
        }
    }
}