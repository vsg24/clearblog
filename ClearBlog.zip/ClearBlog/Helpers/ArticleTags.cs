﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ClearBlog.Models;

namespace ClearBlog.Helpers
{
    public static class ArticleTags
    {
        public static string GetTagName(this List<Tag> tags, int index)
        {
            if (tags.Count > index)
            {
                return tags[index].TagName;
            }
            return null;
        }
    }
}