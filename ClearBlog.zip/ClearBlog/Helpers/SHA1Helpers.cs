﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace ClearBlog.Helpers
{
    public static class SHA1Helpers
    {
        public static string GetSHA1Hash(this string input)
        {
            SHA1 sha1 = SHA1.Create();
            byte[] hashData = sha1.ComputeHash(Encoding.Default.GetBytes(input));
            StringBuilder returnValue = new StringBuilder();

            foreach (byte t in hashData)
            {
                returnValue.Append(t.ToString());
            }

            return returnValue.ToString();
        }

        public static bool ValidateSHA1Hash(this string input, string storedHash)
        {
            string getHashInputData = GetSHA1Hash(input);

            if (string.CompareOrdinal(getHashInputData, storedHash) == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}