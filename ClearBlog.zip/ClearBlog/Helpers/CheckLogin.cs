﻿using System.Web.Mvc;
using System.Web.Routing;

namespace ClearBlog.Helpers
{
    //public static class SessionExtensions
    //{
    //    public static T GetDataFromSession<T>(this HttpSessionStateBase session, string key)
    //    {
    //        return (T)session[key];
    //    }

    //    public static void SetDataInSession<T>(this HttpSessionStateBase session, string key, object value)
    //    {
    //        session[key] = value;
    //    }
    //}

    public class CheckLogin : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (context.HttpContext.Session != null)
            {
                if ((string)context.HttpContext.Session["loggedin"] != "true")
                {
                    RouteValueDictionary redirectTargetDictionary = new RouteValueDictionary
                    {
                        {"action", "login"},
                        {"controller", "account"},
                        {"area", ""}
                    };

                    context.Result = new RedirectToRouteResult(redirectTargetDictionary);
                }
            }

            base.OnActionExecuting(context);
        }
    }
}