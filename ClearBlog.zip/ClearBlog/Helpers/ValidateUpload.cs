﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClearBlog.Helpers
{
    public static class ValidateUpload
    {
        public static bool IsImage(this HttpPostedFileBase file)
        {
            if (file.ContentType.Contains("image"))
            {
                return true;
            }

            string[] formats = new string[] { ".jpg", ".png", ".gif", ".jpeg" }; // add more if u like...

            foreach (var item in formats)
            {
                if (file.FileName.Contains(item))
                {
                    return true;
                }
            }

            return false;
        }
    }
}