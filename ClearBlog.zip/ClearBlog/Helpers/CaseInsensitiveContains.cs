﻿using System;

namespace ClearBlog.Helpers
{
    public static class CaseInsensitiveContains
    {
        public static bool CiContains(this string source, string toCheck, StringComparison comp)
        {
            return source.IndexOf(toCheck, comp) >= 0;
        }
    }
}