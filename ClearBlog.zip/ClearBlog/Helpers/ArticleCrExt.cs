﻿namespace ClearBlog.Helpers
{
    public static class ArticleCrExt
    {
        public static string ArticleCr(this string article, int id, string slug)
        {
            if (slug == "")
            {
                if (id == 0)
                {
                    return article.Replace("[cr]", "");
                }
            }
            
            string url = "/articles/" + id + "/" + slug;
            string replacement = (ClearBlog.Properties.Settings.Default.ArticleContinueReading).Replace("#", url);
            return article.Replace("[cr]", replacement);
        }
    }
}