﻿using System;

namespace ClearBlog.Helpers
{
    public static class ArticleCrExt
    {
        public static string ArticleCr(this string article, int id, string slug, string mark = "")
        {
            if (slug == "")
            {
                if (id == 0)
                {
                    return article.Replace("[cr]", "");
                }
            }

            if (mark != "")
            {
                int index = article.IndexOf("[cr]", StringComparison.Ordinal);
                if (index > 0)
                    article = article.Substring(0, index+4);
            }
            
            string url = "/articles/" + id + "/" + slug;
            string replacement = (ClearBlog.Properties.Settings.Default.ArticleContinueReading).Replace("#", url);
            return article.Replace("[cr]", replacement);
        }
    }
}