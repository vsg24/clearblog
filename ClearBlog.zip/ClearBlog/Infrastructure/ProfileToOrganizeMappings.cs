﻿using AutoMapper;
using ClearBlog.Models;
using ClearBlog.Models.ViewModels;
using ClearBlog.Areas.Admin.Models.ViewModels;

namespace ClearBlog.Infrastructure
{
    public static class AutoMapperWebConfiguration
    {
        public static void Configure()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.AddProfile(new ProfileToOrganizeMappings());
                // Other profiles could be registered here
            });
        }
    }

    public class ProfileToOrganizeMappings : Profile
    {
        protected override void Configure()
        {
            //Mapper.CreateMap<SourceModel, DestinationModel>();
            // Other mappings could be defined here
            Mapper.CreateMap<Article, ArticleViewModel>();
            Mapper.CreateMap<Article, CreateArticleViewModel>();
            Mapper.CreateMap<Comment, CommentViewModel>();
            Mapper.CreateMap<User, UserViewModel>();
            Mapper.CreateMap<Page, PageViewModel>();
        }
    }
}