﻿using Ninject;
using System;
using System.Collections.Generic;
using System.Web.Mvc;
using ClearBlog.IRepository;
using ClearBlog.Repository;
using AutoMapper;

namespace ClearBlog.Infrastructure
{
    public class NinjectDependencyResolver : IDependencyResolver
    {
        private IKernel kernel;
        public NinjectDependencyResolver(IKernel kernelParam)
        {
            kernel = kernelParam;
            AddBindings();
        }
        public object GetService(Type serviceType)
        {
            return kernel.TryGet(serviceType);
        }
        public IEnumerable<object> GetServices(Type serviceType)
        {
            return kernel.GetAll(serviceType);
        }
        private void AddBindings()
        {
            // put bindings here
            // normal form
            // kernel.Bind<IInterface>().To<Implementation>();
            // generic form with one argument
            // kernel.Bind(typeof(IRepository<>)).To(typeof(Repository<>));
            // generic form with more than one argument
            // kernel.Bind(typeof(IRepository<,>)).To(typeof(Repository<,>));
            kernel.Bind(typeof(IGenericRepository<>)).To(typeof(GenericRepository<>));
            //kernel.Bind<IDbInstance>().To<DbInstance>();
            kernel.Rebind<IMappingEngine>().ToMethod(context => Mapper.Engine);
        }
    }
}