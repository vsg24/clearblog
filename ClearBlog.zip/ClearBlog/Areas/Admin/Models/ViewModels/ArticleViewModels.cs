﻿using System;
using System.ComponentModel.DataAnnotations;
using ClearBlog.Models;

namespace ClearBlog.Areas.Admin.Models.ViewModels
{
    public class CreateArticleViewModel
    {
        public int ArticleID { get; set; }
        [Display(Name = "ArticleTitle", ResourceType = typeof(Resources.Global))]
        public string ArticleTitle { get; set; }
        [Display(Name = "ArticleContent", ResourceType = typeof(Resources.Global))]
        public string ArticleContent { get; set; }
        [Display(Name = "UrlSlug", ResourceType = typeof(Resources.Global))]
        public string UrlSlug { get; set; }
        [Display(Name = "Created", ResourceType = typeof(Resources.Global))]
        public Nullable<System.DateTime> ArticleCreated { get; set; }
        [Display(Name = "Updated", ResourceType = typeof(Resources.Global))]
        public Nullable<System.DateTime> ArticleUpdated { get; set; }
        [Display(Name = "Author", ResourceType = typeof(Resources.Global))]
        public Nullable<int> ArticleAuthorID { get; set; }
        [Display(Name = "Tags", ResourceType = typeof(Resources.Global))]
        public string Tags { get; set; }
        [Display(Name = "Status", ResourceType = typeof(Resources.Global))]
        public string ArticleStatus { get; set; }
        [Display(Name = "MetaKeywords", ResourceType = typeof(Resources.Global))]
        public string MetaKeywords { get; set; }
        [Display(Name = "MetaDescription", ResourceType = typeof(Resources.Global))]
        public string MetaDescription { get; set; }
        [Display(Name = "Notes", ResourceType = typeof(Resources.Global))]
        public string Notes { get; set; }
        public virtual User User { get; set; }

        public string ArticleStatusString
        {
            get
            {
                switch (ArticleStatus)
                {
                    case "Pending":
                        return Resources.Global.Pending;
                    case "Published":
                        return Resources.Global.Published;
                    case "Draft":
                        return Resources.Global.Draft;
                    case "Deleted":
                        return Resources.Global.Deleted;
                    default:
                        return Resources.Global.Pending;
                }
            }
        }

        public string ArticleColor
        {
            get
            {
                switch (ArticleStatus)
                {
                    case "Pending":
                        return "warning";
                    case "Published":
                        return "success";
                    case "Draft":
                        return "default";
                    case "Deleted":
                        return "danger";
                    default:
                        return "warning";
                }
            }
        }
    }
}