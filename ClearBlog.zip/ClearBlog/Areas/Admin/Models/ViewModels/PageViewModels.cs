﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ClearBlog.Areas.Admin.Models.ViewModels
{
    public class PageViewModel
    {
        public int PageID { get; set; }
        [Display(Name = "PageTitle", ResourceType = typeof(Resources.Global))]
        public string PageTitle { get; set; }
        [Display(Name = "PageContent", ResourceType = typeof(Resources.Global))]
        public string PageContent { get; set; }
        [Display(Name = "PageSectionA", ResourceType = typeof(Resources.Global))]
        public string PageSectionA { get; set; }
        [Display(Name = "MetaKeywords", ResourceType = typeof(Resources.Global))]
        public string MetaKeywords { get; set; }
        [Display(Name = "MetaDescription", ResourceType = typeof(Resources.Global))]
        public string MetaDescription { get; set; }
        [Display(Name = "UrlSlug", ResourceType = typeof(Resources.Global))]
        public string UrlSlug { get; set; }
    }
}