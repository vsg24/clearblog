﻿//using System;
//using System.Collections.Generic;
//using System.ComponentModel.DataAnnotations;
//using System.Linq;
//using System.Web;

//namespace ClearBlog.Areas.Admin.Models.ViewModels
//{
//    public class UserViewModel
//    {
//        public int UserID { get; set; }
//        [Display(Name = "UserName", ResourceType = typeof(Resources.Global))]
//        public string UserName { get; set; }
//        public string FullName { get; set; }
//        public string Avatar { get; set; }
//        public string Email { get; set; }
//        public string PasswordHash { get; set; }
//        public string SecurityStamp { get; set; }
//        public Nullable<int> AccessFailedCount { get; set; }
//    }
//}