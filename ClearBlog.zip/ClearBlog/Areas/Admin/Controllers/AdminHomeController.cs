﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using ClearBlog.Helpers;
using System.IO;
using System.Threading;

namespace ClearBlog.Areas.Admin.Controllers
{
    [CheckLogin]
    [RoutePrefix("admin")]
    public class AdminHomeController : Controller
    {
        public AdminHomeController()
        {
            SetCulture();
        }

        [Route("")]
        public ActionResult Index()
        {
            return View();
        }

        public PartialViewResult _UserInfo()
        {
            ViewBag.UserName = (string) System.Web.HttpContext.Current.Session["username"];
            ViewBag.UserAvatar = (string) System.Web.HttpContext.Current.Session["useravatar"];

            return PartialView();
        }

        [NonAction]
        public static string Language()
        {
            return ClearBlog.Properties.Settings.Default.Language;
        }

        [NonAction]
        public static List<string> RtlLangs()
        {
            return new List<string> { "fa-IR" };
        }

        [NonAction]
        public static void SetCulture()
        {
            var langs = new List<string> { "en-US", "fa-IR" };
            var langsettings = Language();
            if (langs.Contains(langsettings))
            {
                Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(langsettings);
                Thread.CurrentThread.CurrentUICulture = Thread.CurrentThread.CurrentCulture;
            }
        }

        [Route("")]
        [HttpPost]
        public string Upload(HttpPostedFileBase file)
        {
            string path;
            string saveloc = "~/data/Images/";
            string relativeloc = "/data/Images/";
            string filename = file.FileName;

            if (file != null && file.ContentLength > 0 && file.IsImage())
            {
                try
                {
                    path = Path.Combine(HttpContext.Server.MapPath(saveloc), Path.GetFileName(filename));
                    file.SaveAs(path);
                }
                catch (Exception e)
                {
                    return "<script>alert('Failed: " + e + "');</script>";
                }
            }
            else
            {
                return "<script>alert('Failed: Unkown Error. This form only accepts valid images.');</script>";
            }

            return "<script>top.$('.mce-btn.mce-open').parent().find('.mce-textbox').val('" + relativeloc + filename + "').closest('.mce-window').find('.mce-primary').click();</script>";
        }
    }
}