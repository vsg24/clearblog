﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using AutoMapper;
using ClearBlog.Helpers;
using ClearBlog.IRepository;
using ClearBlog.Models;
using ClearBlog.Areas.Admin.Models.ViewModels;

namespace ClearBlog.Areas.Admin.Controllers
{
    [CheckLogin]
    [RoutePrefix("admin/pages")]
    public class AdminPagesController : Controller
    {
        private readonly IMappingEngine _mapper = null;
        private readonly IGenericRepository<Page> _db = null;

        public AdminPagesController(IGenericRepository<Page> db, IMappingEngine mapper)
        {
            AdminHomeController.SetCulture();
            _db = db;
            _mapper = mapper;
        }

        [Route("")]
        public ActionResult Index()
        {
            var pages = _db.SelectAll();

            var newpages = new List<PageViewModel>();

            foreach (var item in pages)
            {
                PageViewModel singlearticle = _mapper.Map<Page, PageViewModel>(item);
                newpages.Add(singlearticle);
            }

            return View(newpages);
        }

        [Route("create")]
        public ActionResult Create()
        {
            var createpage = new PageViewModel();
            return View(createpage);
        }

        [Route("create")]
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "PageID,PageTitle,PageContent,UrlSlug,MetaDescription,MetaKeywords")] Page page)
        {
            if (ModelState.IsValid)
            {
                _db.Insert(page);
                _db.Save();

                return RedirectToAction("Edit", new { id = page.PageID });
            }

            PageViewModel createpage = _mapper.Map<Page, PageViewModel>(page);
            return View(createpage);
        }

        [Route("edit/{id:int}")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Page page = _db.SelectAll().SingleOrDefault(x => x.PageID == id);
            if (page == null)
            {
                return HttpNotFound();
            }

            PageViewModel createpage = _mapper.Map<Page, PageViewModel>(page);

            return View(createpage);
        }

        [Route("edit/{id:int}")]
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "PageID,PageTitle,PageContent,UrlSlug,MetaDescription,MetaKeywords")] Page page)
        {
            if (ModelState.IsValid)
            {
                _db.Update(page);
                _db.Save();
                return RedirectToAction("Index");
            }
            // ReSharper disable once Mvc.InvalidModelType
            return View(page);
        }

        [Route("delete/{id:int}")]
        [HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            _db.Delete(id);
            _db.Save();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}