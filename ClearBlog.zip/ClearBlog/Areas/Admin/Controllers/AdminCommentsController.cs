﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using AutoMapper;
using ClearBlog.Helpers;
using ClearBlog.IRepository;
using ClearBlog.Models;
using ClearBlog.Models.ViewModels;

namespace ClearBlog.Areas.Admin.Controllers
{
    [CheckLogin]
    [RoutePrefix("admin/comments")]
    public class AdminCommentsController : Controller
    {
        private readonly IMappingEngine _mapper = null;
        private readonly IGenericRepository<Comment> _db = null;

        public AdminCommentsController(IMappingEngine mapper, IGenericRepository<Comment> db)
        {
            AdminHomeController.SetCulture();
            _db = db;
            _mapper = mapper;
        }

        [Route("")]
        public ActionResult Index()
        {
            var comments = _db.SelectAll();

            var newcomments = new List<CommentViewModel>();

            foreach (var item in comments)
            {
                CommentViewModel singlecomment = _mapper.Map<Comment, CommentViewModel>(item);
                newcomments.Add(singlecomment);
            }
            return View(newcomments);
        }

        // GET: Admin/AdminComments/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Admin/AdminComments/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Admin/AdminComments/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public PartialViewResult _GetComments(int articleid)
        {
            var allcomments = _db.SelectAll();
            var thisarticlecomments = from c in allcomments
                where c.ArticleID == articleid
                select c;

            var newcomments = new List<CommentViewModel>();

            foreach (var item in thisarticlecomments)
            {
                CommentViewModel singlecomment = _mapper.Map<Comment, CommentViewModel>(item);
                newcomments.Add(singlecomment);
            }

            return PartialView("_GetComments", newcomments);
        }

        // GET: Admin/AdminComments/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Admin/AdminComments/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        [Route("rejectajax")]
        [HttpPost]
        public JsonResult RejectAjax(int id)
        {
            var comment = _db.SelectById(id);
            comment.CommentStatus = "Rejected";
            _db.Update(comment);
            _db.Save();
            return Json(new {success = true});
        }

        [Route("approveajax")]
        [HttpPost]
        public JsonResult ApproveAjax(int id)
        {
            var comment = _db.SelectById(id);
            comment.CommentStatus = "Approved";
            _db.Update(comment);
            _db.Save();
            return Json(new { success = true });
        }

        [Route("changeajax")]
        [HttpPost]
        public JsonResult ChangeAjax(int id, string action)
        {
            if (action == "D")
            {
                var delres = DeleteAjax(id);
                if (delres) goto end;
            }
            var comment = _db.SelectById(id);
            var status = (action == "A") ? "Approved" : "Rejected";
            comment.CommentStatus = status;
            _db.Update(comment);
            _db.Save();
            end:
            return Json(new { success = true });
        }

        [NonAction]
        public bool DeleteAjax(int id)
        {
            _db.Delete(id);
            _db.Save();
            return true;
        }

        // POST: Admin/AdminComments/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
