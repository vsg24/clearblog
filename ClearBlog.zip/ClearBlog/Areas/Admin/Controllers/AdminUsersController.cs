﻿using System.Web.Mvc;
using AutoMapper;
using ClearBlog.Models;
using ClearBlog.Helpers;
using ClearBlog.IRepository;
using ClearBlog.Models.ViewModels;

namespace ClearBlog.Areas.Admin.Controllers
{
    [CheckLogin]
    [RoutePrefix("admin/users")]
    public class AdminUsersController : Controller
    {
        private readonly IGenericRepository<User> _db = null;
        private readonly IMappingEngine _mapper = null;

        public AdminUsersController(IGenericRepository<User> db, IMappingEngine mapper)
        {
            AdminHomeController.SetCulture();
            _db = db;
            _mapper = mapper;
        }

        [Route("")]
        public ActionResult Index()
        {
            ViewBag.UserAvatar = (string)System.Web.HttpContext.Current.Session["useravatar"];
            return View(_db.SelectAll());
        }

        [Route("create")]
        public ActionResult Create()
        {
            return View();
        }

        [Route("create")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "UserName,FullName,Email,Avatar,PasswordHash")] User user)
        {
            if (ModelState.IsValid)
            {
                user.PasswordHash = user.PasswordHash.GetSHA1Hash();

                //// Another way

                //var data = Encoding.ASCII.GetBytes(value);
                //var hashData = new SHA1Managed().ComputeHash(data);

                //var hash = string.Empty;

                //foreach (var b in hashData)
                //    hash += b.ToString("X2");

                //return hash;

                //// Done

                _db.Insert(user);
                _db.Save();
                return RedirectToAction("Index");
            }

            return View(user);
        }

        [Route("edit/{id:int}")]
        public ActionResult Edit(int id)
        {
            User user = _db.SelectById(id);
            if (user == null)
            {
                return HttpNotFound();
            }

            UserViewModel uvm = _mapper.Map<User, UserViewModel>(user);
            uvm.PasswordHash = null;

            return View(uvm);
        }

        [Route("edit/{id:int}")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "UserID,UserName,FullName,Email,Avatar,PasswordHash")] User user)
        {
            if (ModelState.IsValid)
            {
                user.PasswordHash = user.PasswordHash.GetSHA1Hash();
                _db.Update(user);
                _db.Save();
                return RedirectToAction("Index");
            }
            UserViewModel uvm = _mapper.Map<User, UserViewModel>(user);
            return View(uvm);
        }

        [Route("delete/{id:int}")]
        public ActionResult Delete(int id)
        {
            User user = _db.SelectById(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        [Route("delete/{id:int}")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            User user = _db.SelectById(id);
            _db.Delete(id);
            _db.Save();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
