﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using ClearBlog.Models;
using ClearBlog.Areas.Admin.Models.ViewModels;
using ClearBlog.Helpers;
using AutoMapper;
using ClearBlog.IRepository;
using ClearBlog.Models.ViewModels;

namespace ClearBlog.Areas.Admin.Controllers
{
    [CheckLogin]
    [RoutePrefix("admin/articles")]
    public class AdminArticlesController : Controller
    {
        private readonly IMappingEngine _mapper = null;
        private readonly IGenericRepository<Article> _db = null;
        private readonly IGenericRepository<User> _db2 = null;
        private readonly IGenericRepository<ArticleTag> _db3 = null;
        private readonly IGenericRepository<Comment> _db4 = null;

        public AdminArticlesController(IGenericRepository<Article> db, IMappingEngine mapper, IGenericRepository<User> db2, IGenericRepository<ArticleTag> db3, IGenericRepository<Comment> db4)
        {
            AdminHomeController.SetCulture();
            _db = db;
            _db2 = db2;
            _db3 = db3;
            _db4 = db4;
            _mapper = mapper;
        }

        [Route("")]
        public ActionResult Index()
        {
            var articles = _db.SelectAll();

            var newarticles = new List<ArticleViewModel>();

            var i = 0;
            foreach (var item in articles)
            {
                ArticleViewModel singlearticle = _mapper.Map<Article, ArticleViewModel>(item);
                newarticles.Add(singlearticle);
                newarticles[i].Tags = this.GetArticleTags(newarticles[i].ArticleID);
                newarticles[i].CommentCount = this.GetCommentCount(newarticles[i].ArticleID);
                i++;
            }

            return View(newarticles);
        }

        [Route("create")]
        public ActionResult Create()
        {
            ViewBag.ArticleAuthorID = new SelectList(_db2.SelectAll(), "UserID", "UserName");
            var createarticle = new CreateArticleViewModel();
            return View(createarticle);
        }

        [Route("create")]
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ArticleID,ArticleTitle,ArticleContent,UrlSlug,ArticleCreated,ArticleAuthorID,ArticleStatus,MetaDescription,MetaKeywords,Notes")] Article article)
        {
            if (ModelState.IsValid)
            {
                _db.Insert(article);
                _db.Save();

                return RedirectToAction("Edit", new { id = article.ArticleID });
            }

            CreateArticleViewModel createarticle = _mapper.Map<Article, CreateArticleViewModel>(article);
            ViewBag.ArticleAuthorID = new SelectList(_db2.SelectAll(), "UserID", "UserName", article.ArticleAuthorID);

            return View(createarticle);
        }

        [Route("edit/{id:int}")]
        public ActionResult Edit(int? id)
        {
            //AdminHomeController.SetCulture();
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Article article = _db.SelectAll().SingleOrDefault(x => x.ArticleID == id);
            if (article == null)
            {
                return HttpNotFound();
            }

            ViewBag.ArticleAuthorID = article.User.UserName;

            CreateArticleViewModel createarticle = _mapper.Map<Article, CreateArticleViewModel>(article);

            return View(createarticle);
        }

        [Route("edit/{id:int}")]
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ArticleID,ArticleTitle,ArticleContent,UrlSlug,ArticleCreated,ArticleUpdated,ArticleAuthorID,ArticleStatus,MetaDescription,MetaKeywords,Notes")] Article article)
        {
            if (ModelState.IsValid)
            {
                _db.Update(article);
                _db.Save();
                return RedirectToAction("Index");
            }
            ViewBag.ArticleAuthorID = new SelectList(_db2.SelectAll(), "UserID", "UserName", article.ArticleAuthorID);
            // ReSharper disable once Mvc.InvalidModelType
            return View(article);
        }

        //[Route("delete/{id:int}")]
        //public ActionResult Delete(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    Article article = _db.SelectById(id);
        //    if (article == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(article);
        //}

        [Route("delete/{id:int}")]
        [HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            _db.Delete(id);
            _db.Save();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
            base.Dispose(disposing);
        }

        public List<Tag> GetArticleTags(int id)
        {
            var alltags = _db3.SelectAll();
            var tags = from t in alltags
                       where t.ArticleID == id
                       select t.Tag;

            var result = tags.ToList();
            return result;
        }

        public string GetCommentCount(int id)
        {
            var allcomments = _db4.SelectAll();
            var comments = from c in allcomments
                           where c.ArticleID == id
                           select c;
            return comments.ToList().Count.ToString();
        }
    }
}
