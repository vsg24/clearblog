﻿using System.Linq;
using System.Net;
using System.Web.Mvc;
using ClearBlog.Models;
using ClearBlog.Helpers;
using ClearBlog.IRepository;

namespace ClearBlog.Areas.Admin.Controllers
{
    [CheckLogin]
    [RoutePrefix("admin/tags")]
    public class AdminTagsController : Controller
    {
        private readonly IGenericRepository<Tag> _db = null;
        private readonly AdminArticleTagsController _mAdminArticleTags;

        public AdminTagsController(IGenericRepository<Tag> db, AdminArticleTagsController aat)
        {
            AdminHomeController.SetCulture();
            _db = db;
            _mAdminArticleTags = aat;
        }

        [Route("")]
        public ActionResult Index()
        {
            return View(_db.SelectAll());
        }

        [Route("create")]
        public ActionResult Create()
        {
            return View();
        }

        [Route("create")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "TagID,TagName")] Tag tag)
        {
            if (ModelState.IsValid)
            {
                var alltags = _db.SelectAll();

                var checkquery = from t in alltags
                                 where t.TagName == tag.TagName
                                 select t;

                var checkresult = checkquery.ToList();

                if (checkresult.Count <= 0)
                {
                    _db.Insert(tag);
                    _db.Save();
                    return RedirectToAction("Index");
                }
                return RedirectToAction("Index");
            }

            return View(tag);
        }

        [Route("createajax")]
        [HttpPost]
        public JsonResult CreateAjax(int id, [Bind(Include = "TagID,TagName")] Tag tag)
        {
            var alltags = _db.SelectAll().ToList();
            var checkquery = from t in alltags
                                where t.TagName == tag.TagName
                                select t;

            var checkresult = checkquery.ToList();
            var tagid = 0;
            ArticleTag res = null;

            if (checkresult.Count <= 0)
            {
                _db.Insert(tag);
                _db.Save();

                tagid = tag.TagID;
                var articleid = id;

                res = _mAdminArticleTags.InsertNew(articleid, tagid);
            }
            else
            {
                var og = checkresult.ToList();
                tagid = og.First().TagID;

                var articleid = id;

                res = _mAdminArticleTags.InsertNew(articleid, tagid);
            }

            return Json(new { success = true, tag = tag.TagName, articletagid = res.ArticleTagID });
        }

        [Route("details/{id:int}")]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Tag tag = _db.SelectById(id);
            if (tag == null)
            {
                return HttpNotFound();
            }
            return View(tag);
        }

        [Route("edit/{id:int}")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Tag tag = _db.SelectById(id);
            if (tag == null)
            {
                return HttpNotFound();
            }
            return View(tag);
        }

        //[Route("edit/{id:int}")]
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Edit([Bind(Include = "TagID,TagName")] Tag tag)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _db.Update(tag);
        //        _db.Save();
        //        return RedirectToAction("Index");
        //    }
        //    return View(tag);
        //}

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public JsonResult EditAjax([Bind(Include = "TagID,TagName")] Tag tag)
        {
            if (ModelState.IsValid)
            {
                _db.Update(tag);
                _db.Save();
                return Json(new { success = true });
            }
            return Json(new { success = false });
        }

        [Route("deleteajax")]
        [HttpPost]
        public JsonResult DeleteAjax(int id)
        {
            _db.Delete(id);
            _db.Save();
            return Json(new { success = true });
        }

        [Route("delete/{id:int}")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Tag tag = _db.SelectById(id);
            if (tag == null)
            {
                return HttpNotFound();
            }
            return View(tag);
        }

        [Route("delete/{id:int}")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            _db.Delete(id);
            _db.Save();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
