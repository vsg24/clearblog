﻿using System.Linq;
using System.Web.Mvc;
using ClearBlog.Helpers;
using ClearBlog.IRepository;
using ClearBlog.Models;

namespace ClearBlog.Areas.Admin.Controllers
{
    [CheckLogin]
    [RoutePrefix("admin/articletags")]
    public class AdminArticleTagsController : Controller
    {
        private readonly IGenericRepository<ArticleTag> _db = null;

        public AdminArticleTagsController(IGenericRepository<ArticleTag> db)
        {
            AdminHomeController.SetCulture();
            _db = db;
        }

        public AdminArticleTagsController()
        {}

        public ArticleTag InsertNew(int article, int tag)
        {
            ArticleTag at = new ArticleTag()
            {
                ArticleID = article,
                TagID = tag
            };

            _db.Insert(at);
            _db.Save();

            return at;
        }

        //[Route("deletearticletag")]
        //[HttpGet]
        //public JsonResult DeleteArticleTag(int id)
        //{
        //    _db.Delete(id);
        //    _db.Save();

        //    return Json(new {success = true, atid = id}, JsonRequestBehavior.AllowGet);
        //}

        [Route("deletearticletag")]
        [HttpGet]
        public JsonResult DeleteArticleTag(int id)
        {
            _db.Delete(id);
            _db.Save();

            return Json(new { success = true, atid = id }, JsonRequestBehavior.AllowGet);
        }

        public PartialViewResult _GetTags(int articleid)
        {
            var alltags = _db.SelectAll();
            var thisarticletags = from tat in alltags
                where tat.ArticleID == articleid
                select tat;

            return PartialView("_GetTags", thisarticletags.ToList());
        }
    }
}