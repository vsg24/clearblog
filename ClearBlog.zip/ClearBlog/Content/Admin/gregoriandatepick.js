﻿function gregoriandatepick(input, button, hiddenfield) {
    Calendar.setup({
        inputField: input,   // id of the input field
        button: button,   // trigger for the calendar (button ID)
        ifFormat: "%m/%d/%Y %H:%M",       // format of the input field
        showsTime: true,
        dateType: 'gregorian',
        timeFormat: "24",
        weekNumbers: false,
        onUpdate: fixDate
    });

    inputv = input;
    hiddenfieldv = hiddenfield;
}

function fixDate() {
    var input = inputv;
    var hiddenfield = hiddenfieldv;
    var datetime = $("#" + input).val();
    var gregdatetime = moment(datetime, "MM/DD/YYYY HH:mm").format("MM/DD/YYYY HH:mm");
    $("#" + hiddenfield).val(gregdatetime);
}