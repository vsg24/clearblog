﻿$(document).ready(function() {

    // form submit start

    $('#form_submit').click(function() {
        $('#spinner-main').append(getSpinner());
        $('#ArticleStatus').val('Published');
        $('#articleform').submit();
    });

    // form submit end

    // draft submit start

    $('#draft_submit').click(function() {

        $('#spinner-main').append(getSpinner());

        $.ajax({
            type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url: $('#articleform').attr('action'), // the url where we want to POST
            contentType: 'application/json; charset=utf-8', // sent data type
            data: JSON.stringify({ article: { ArticleID: @ViewContext.RouteData.Values["id"], ArticleTitle: $('#ArticleTitle').val(), ArticleContent: $('[name="ArticleContent"]').val(), UrlSlug: $('#UrlSlug').val(), ArticleCreated: $('#ArticleCreated').val(), ArticleAuthorID: $('#ArticleAuthorID').val(), ArticleStatus: 'Draft' } }),
            dataType: 'json', // what type of data do we expect back from the server
            encode: true
        })


            // ajax call succeeds
            .done(function(data) {

                // here we will handle errors and validation messages
                if (data.success) {
                    // server side validation succeeds
                }
            })

            // ajax call fails
            .fail(function(jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == 200) {
                    $('#draft_submit').css('background-color', '#6AC720');
                    $('#draft_submit').css('color', '#fff');
                    $('#articlestatus').load(location.href + " #articlestatus");
                    hideSpinner();
                } else {
                    console.log(jqXHR);
                    console.log('AJAX Error');
                }
            });

        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

    });

    // draft submit ends

    // remove submit start

    $('#remove_submit').click(function() {

        $('#spinner-main').append(getSpinner());

        $.ajax({
            type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url: '@Url.Action("delete", "AdminArticles")', // the url where we want to POST
            contentType: 'application/json; charset=utf-8', // sent data type
            data: JSON.stringify({ id: @ViewContext.RouteData.Values["id"] }),
            dataType: 'json', // what type of data do we expect back from the server
            encode: true
        })


            // ajax call succeeds
            .done(function(data) {

                // here we will handle errors and validation messages
                if (data.success) {
                    // server side validation succeeds
                }
            })

            // ajax call fails
            .fail(function(jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == 200) {
                    document.location.replace('@Url.Action("index", "AdminArticles")');
                } else {
                    console.log(jqXHR);
                    console.log('AJAX Error');
                }
            });

        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

    });

    // remove submit end

    jQuery(document).on('click', '#TagSubmit', function(event) {

        $('#spinner-tag').append(getSpinner());

        if ($('#Tag').val().length === 0) {
            alert('Can\'t be empty!');
            event.preventDefault();
            throw new Error("Something went badly wrong!");
        }

        // process the form
        $.ajax({
            type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url: '/admin/tags/createajax', // the url where we want to POST
            contentType: 'application/json; charset=utf-8', // sent data type
            data: JSON.stringify({ id: @ViewContext.RouteData.Values["id"], tag: { TagId: null, TagName: $('#Tag').val() } }),
            dataType: 'json', // what type of data do we expect back from the server
            encode: true
        })

            // ajax call succeeds
            .done(function(data) {

                // here we will handle errors and validation messages
                if (data.success) {
                    // server side validation succeeds
                    $('#tagsdiv').load(location.href + " #tagsdiv");
                    $('#Tag').val('');
                    hideSpinner();
                } else {
                    // server side validation fails
                    $('#Tag').val('Failed');
                    hideSpinner();
                }
            })

            // ajax call fails
            .fail(function(data) {
                console.log(data);
                console.log('AJAX Error');
                hideSpinner();
            });

        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
    });

});