﻿
// This function is designed to work with 'Angle' theme
// It requires jQuery

/*

Usage:

<div id="og"></div>

<script>

// show spinner on targer
$('#target').append(getSpinner());

// hide spinner (with default class)
hideSpinner();

</script>
*/

function getSpinner(mode, name) {
    mode = typeof mode !== 'undefined' ? mode : 'loader demo';
    name = typeof name !== 'undefined' ? name : 'semi-circle-spin';
    return '<div class="panel-body ' + mode + '"><div class="' + name + '"><div></div></div></div>';
}

function hideSpinner() {
    $('.loader').hide();
}