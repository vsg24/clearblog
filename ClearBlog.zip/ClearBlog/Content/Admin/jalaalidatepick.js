﻿function jalaalidatepick(input, button, hiddenfield) {
    Calendar.setup({
        inputField: input,   // id of the input field
        button: button,   // trigger for the calendar (button ID)
        ifFormat: "%Y/%m/%d %H:%M",       // format of the input field
        showsTime: true,
        dateType: 'jalali',
        timeFormat: "24",
        weekNumbers: false,
        onUpdate: fixDate
    });

    inputv = input;
    hiddenfieldv = hiddenfield;
}

function fixDate() {
    var input = inputv;
    var hiddenfield = hiddenfieldv;
    var datetime = $("#" + input).val();
    //var gregdatetime = moment(datetime, "jYYYY/jMM/jDD HH:mm").format("YYYY/MM/DD HH:mm");
    $("#" + hiddenfield).val(datetime);
}

function toJalaali(date, input) {
    if (date == '') {
        return null;
    }
    var greg = moment(date, "YYYY/MM/DD HH:mm").format("jYYYY/jMM/jDD HH:mm");
    $(input).val(greg);
    return null;
}