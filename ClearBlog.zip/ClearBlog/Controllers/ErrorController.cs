﻿using System.Web.Mvc;

namespace ClearBlog.Controllers
{
    public class ErrorController : Controller
    {
        public ErrorController()
        {
            Areas.Admin.Controllers.AdminHomeController.SetCulture();
        }

        public ActionResult NotFound()
        {
            // Return a status code for proper SEO
            Response.StatusCode = 404;

            return View();
        }

        public ActionResult ServerError()
        {
            // Return a status code for proper SEO
            Response.StatusCode = 500;

            return View();
        }
    }
}