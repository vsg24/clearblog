﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using ClearBlog.Models;
using ClearBlog.Models.ViewModels;
using ClearBlog.IRepository;
using AutoMapper;
using ClearBlog.Areas.Admin.Models.ViewModels;
using ClearBlog.Helpers;
using PagedList;

namespace ClearBlog.Controllers
{
    [RoutePrefix("articles")]
    public class ArticlesController : Controller
    {
        private readonly IMappingEngine _mapper = null;
        private readonly IGenericRepository<Article> _db = null;
        private readonly IGenericRepository<ArticleTag> _db2 = null;
        private readonly IGenericRepository<Comment> _db3 = null;
        private readonly IGenericRepository<Page> _db4 = null;

        public ArticlesController(IMappingEngine mapper, IGenericRepository<Article> db,
            IGenericRepository<ArticleTag> db2, IGenericRepository<Comment> db3, IGenericRepository<Page> db4)
        {
            _mapper = mapper;
            _db = db;
            _db2 = db2;
            _db3 = db3;
            _db4 = db4;
        }

        [Route("~/{page:int?}")]
        public ActionResult Index(int? page)
        {
            int pageNumber = page ?? 1;
            int pageCount = Properties.Settings.Default.MaxArticlePerPage; // maximum number of entries in each page

            var allarticles = _db.SelectAll();
            var orderedpaged = from a in allarticles
                               orderby a.ArticleCreated descending
                               select a;

            var articles = new List<ArticleViewModel>();

            var i = 0;
            foreach (var item in orderedpaged)
            {
                ArticleViewModel singlearticle = _mapper.Map<Article, ArticleViewModel>(item);
                articles.Add(singlearticle);
                articles[i].Tags = this.GetArticleTags(articles[i].ArticleID);
                articles[i].CommentCount = this.GetCommentCount(articles[i].ArticleID);
                i++;
            }

            ViewBag.MetaDescription = Properties.Settings.Default.IndexMetadescription;
            ViewBag.MetaKeywords = Properties.Settings.Default.IndexMetakeywords;
            ViewBag.CurrentBlogPageUrl = Properties.Settings.Default.BlogUrl + page;
            ViewBag.NextBlogPageUrl = Properties.Settings.Default.BlogUrl + (pageNumber + 1);

            return View((IPagedList<ArticleViewModel>)articles.ToPagedList(pageNumber, pageCount));
        }

        [Route("browse/{year:length(4)}/{month:int?}/{page:int?}")]
        public ActionResult ArchiveIndex(int year, int? month, int? page)
        {
            int pageNumber = page ?? 1;
            int pageCount = Properties.Settings.Default.MaxArticlePerPage; // maximum number of entries in each page

            var articles = new List<ArticleViewModel>();

            if (month == null)
            {
                var allarticles = _db.SelectAll();

                var onlyinyear = from a in allarticles
                                 where a.ArticleCreated.Year == year
                                 orderby a.ArticleCreated.Year descending
                                 select a;

                var i = 0;
                foreach (var item in onlyinyear)
                {
                    ArticleViewModel singlearticle = _mapper.Map<Article, ArticleViewModel>(item);
                    articles.Add(singlearticle);
                    articles[i].Tags = this.GetArticleTags(articles[i].ArticleID);
                    articles[i].CommentCount = this.GetCommentCount(articles[i].ArticleID);
                    i++;
                }

                return View("~/Views/Articles/Index.cshtml", articles.ToPagedList(pageNumber, pageCount));
            }
            else
            {
                var allarticles = _db.SelectAll();

                var selectedarchive = from a in allarticles
                                      where a.ArticleCreated.Year == year
                                            && a.ArticleCreated.Month == month
                                      orderby a.ArticleCreated.Month descending
                                      select a;

                var i = 0;
                foreach (var item in selectedarchive)
                {
                    ArticleViewModel singlearticle = _mapper.Map<Article, ArticleViewModel>(item);
                    articles.Add(singlearticle);
                    articles[i].Tags = this.GetArticleTags(articles[i].ArticleID);
                    articles[i].CommentCount = this.GetCommentCount(articles[i].ArticleID);
                    i++;
                }

                return View("~/Views/Articles/Index.cshtml", articles.ToPagedList(pageNumber, pageCount));
            }
        }

        [Route("browse/{tagname}/{page:int?}")]
        public ActionResult TagArticlesIndex(string tagname, int? page)
        {
            int pageNumber = page ?? 1;
            int pageCount = Properties.Settings.Default.MaxArticlePerPage; // maximum number of entries in each page

            var articles = new List<ArticleViewModel>();

            //if (tagname == null)
            //{
            //    return RedirectToAction("index");
            //}
            //else
            {
                var allarticles = _db.SelectAll();
                var allarticletags = _db2.SelectAll();

                var selectedarticles = from a in allarticletags
                    where a.Tag.TagName == tagname
                    select a.Article;

                var i = 0;
                foreach (var item in selectedarticles)
                {
                    ArticleViewModel singlearticle = _mapper.Map<Article, ArticleViewModel>(item);
                    articles.Add(singlearticle);
                    articles[i].Tags = this.GetArticleTags(articles[i].ArticleID);
                    articles[i].CommentCount = this.GetCommentCount(articles[i].ArticleID);
                    i++;
                }

                return View("~/Views/Articles/Index.cshtml", articles.ToPagedList(pageNumber, pageCount));
            }
        }

        [Route("~/search/{s?}/{page:int?}")]
        public ActionResult SearchIndex(string s, int? page)
        {
            if (string.IsNullOrEmpty(s))
            {
                return RedirectToAction("Index");
            }

            int pageNumber = page ?? 1;
            int pageCount = Properties.Settings.Default.MaxArticlePerPage; // maximum number of entries in each page

            var allarticles = _db.SelectAll();

            var result = new List<Article>();

            var searchitems = from a in allarticles
                where a.ArticleTitle.CiContains(s, StringComparison.OrdinalIgnoreCase) || a.ArticleContent.CiContains(s, StringComparison.OrdinalIgnoreCase)
                select a;

            var allarticletags = _db2.SelectAll();

            foreach (var atag in allarticletags)
            {
                var item = atag.Tag.TagName.CiContains(s, StringComparison.OrdinalIgnoreCase);
                if (item)
                {
                    if (!searchitems.Contains(atag.Article))
                    {
                        result.Add(atag.Article);
                    }
                }
            }

            foreach (var item in searchitems)
            {
                result.Add(item);
            }

            var articles = new List<ArticleViewModel>();

            var i = 0;
            foreach (var item in result)
            {
                ArticleViewModel singlearticle = _mapper.Map<Article, ArticleViewModel>(item);
                articles.Add(singlearticle);
                articles[i].Tags = this.GetArticleTags(articles[i].ArticleID);
                articles[i].CommentCount = this.GetCommentCount(articles[i].ArticleID);
                i++;
            }

            var orderedpaged = from a in articles
                               orderby a.ArticleCreated descending
                               select a;

            ViewBag.SearchString = s;

            return View("~/Views/Articles/Index.cshtml", (IPagedList<ArticleViewModel>)orderedpaged.ToPagedList(pageNumber, pageCount));
        }

        // GET: articles/12/article-url-slug
        [Route("{id:int}/{urlslug}")]
        public ActionResult Single(int id, string urlslug)
        {
            Article article = _db.SelectById(id);

            if (article == null)
            {
                return HttpNotFound();
            }

            ArticleViewModel singlearticle = _mapper.Map<Article, ArticleViewModel>(article);

            singlearticle.Tags = this.GetArticleTags(id);
            singlearticle.CommentCount = this.GetCommentCount(id);

            ViewBag.MetaKeywords = singlearticle.MetaKeywords;
            ViewBag.MetaDescription = singlearticle.MetaDescription;
            ViewBag.CurrentBlogPageUrl = Properties.Settings.Default.BlogUrl + "articles/" + id + "/" + urlslug;

            return View(singlearticle);
        }

        [Route("~/static/{urlslug}")]
        public ActionResult Page(string urlslug)
        {
            var allpages = _db4.SelectAll();

            var page = from p in allpages
                where p.UrlSlug == urlslug
                select p;

            if (!page.Any())
            {
                return HttpNotFound();
            }

            PageViewModel thispage = _mapper.Map<Page, PageViewModel>(page.First());

            return View(thispage);
        }

        public List<Tag> GetArticleTags(int id)
        {
            var alltags = _db2.SelectAll();
            var tags = from t in alltags
                where t.ArticleID == id
                select t.Tag;

            var result = tags.ToList();
            return result;
        }

        public string GetCommentCount(int id)
        {
            var allcomments = _db3.SelectAll();
            var comments = from c in allcomments
                           where c.ArticleID == id && c.CommentStatus != "Rejected"
                           select c;
            return comments.ToList().Count.ToString();
        }

        [NonAction]
        public static string GetTitle()
        {
            return Properties.Settings.Default.Title;
        }
    }
}
