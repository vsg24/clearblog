﻿using System;
using System.Linq;
using System.Web.Mvc;
using ClearBlog.IRepository;
using ClearBlog.Models;
using ClearBlog.Models.ViewModels;

namespace ClearBlog.Controllers
{
    [RoutePrefix("comments")]
    public class CommentsController : Controller
    {
        private readonly IGenericRepository<Comment> _db = null;

        public CommentsController(IGenericRepository<Comment> db)
        {
            _db = db;
        }

        public PartialViewResult _Comments(int articleid)
        {
            var allcomments = _db.SelectAll();
            var comments = from c in allcomments
                where c.ArticleID == articleid
                select c;

            var result = comments.ToList();

            return PartialView(result);
        }

        public PartialViewResult _CreateComment()
        {
            return PartialView(new CommentViewModel());
        }

        [HttpPost]
        public PartialViewResult _CreateComment(Comment comment)
        {
            comment.CommentDateTime = DateTime.Now;
            if (ModelState.IsValid)
            {
                _db.Insert(comment);
                _db.Save();
            }

            //CreateArticleViewModel createarticle = _mapper.Map<Article, CreateArticleViewModel>(article);

            return PartialView(new CommentViewModel());
        }

        // GET: Comments/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Comments/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Comments/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Comments/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
