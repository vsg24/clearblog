﻿using System.Linq;
using ClearBlog.Helpers;
using System.Web.Mvc;
using AutoMapper;
using ClearBlog.Areas.Admin.Controllers;
using ClearBlog.Models;
using ClearBlog.Models.ViewModels;
using ClearBlog.Repository;

namespace ClearBlog.Controllers
{
    [RoutePrefix("account")]
    public class AccountController : Controller
    {
        private readonly GenericRepository<User> _db = new GenericRepository<User>();
        private readonly IMappingEngine _mapper = null;

        public AccountController(IMappingEngine mapper)
        {
            AdminHomeController.SetCulture();
            _mapper = mapper;
        }

        [Route("login")]
        public ActionResult Login()
        {
            return View(new UserViewModel());
        }

        [Route("login")]
        [HttpPost]
        public ActionResult Login([Bind(Include = "Email,PasswordHash")] User user)
        {
            if (ModelState.IsValid)
            {
                UserViewModel uservm = _mapper.Map<User, UserViewModel>(user);

                var allusers = _db.SelectAll();
                var findmatchuser = from a in allusers
                    where a.Email == user.Email
                    select a;

                findmatchuser = findmatchuser.ToList();
                if (findmatchuser.Any())
                {
                    if (user.PasswordHash.ValidateSHA1Hash(findmatchuser.First().PasswordHash))
                    {
                        System.Web.HttpContext.Current.Session["loggedin"] = "true";
                        System.Web.HttpContext.Current.Session["username"] = findmatchuser.First().UserName;
                        System.Web.HttpContext.Current.Session["userid"] = findmatchuser.First().UserID;
                        System.Web.HttpContext.Current.Session["useravatar"] = "data/Avatars/" + findmatchuser.First().Avatar;

                        return RedirectToAction("Index", "AdminHome");
                    }
                    else
                    {
                        ViewBag.Error = Resources.Global.EmailPasswordWrong;

                        return View(uservm);
                    }
                }
                else
                {
                    ViewBag.Error = Resources.Global.EmailPasswordWrong;

                    return View(uservm);

                }
            }
            else
            {
                return View();
            }
        }

        [Route("logoff")]
        [HttpPost]
        public JsonResult Logoff()
        {
            if (System.Web.HttpContext.Current.Session != null)
            {
                System.Web.HttpContext.Current.Session["loggedin"] = null;
                System.Web.HttpContext.Current.Session["username"] = null;

                return Json(new {success = true});
            }
            else
            {
                return Json(new {success = false});
            }
        }
    }
}