﻿using System.Linq;
using System.Web.Mvc;
using ClearBlog.IRepository;
using ClearBlog.Models;
using ClearBlog.Models.ViewModels;

namespace ClearBlog.Controllers
{
    public class WidgetsController : Controller
    {
        private readonly IGenericRepository<Article> _db = null;
        private readonly IGenericRepository<Tag> _db2 = null; 

        public WidgetsController(IGenericRepository<Article> db, IGenericRepository<Tag> db2)
        {
            _db = db;
            _db2 = db2;
        }

        public PartialViewResult _LatestArticlesWidget()
        {
            var allarticles = _db.SelectAll();
            var lastarticles = from a in allarticles
                               orderby a.ArticleCreated descending
                               select a;

            return PartialView(lastarticles.Take(Properties.Settings.Default.LatestArticlesWidget));
        }

        public PartialViewResult _MonthlyArchiveWidget()
        {
            var allarticles = _db.SelectAll();
            allarticles = allarticles.Reverse();

            var model = allarticles
                .GroupBy(o => new
                {
                    o.ArticleCreated.Month, o.ArticleCreated.Year
                })
                .Select(g => new ArchiveArticles
                {
                    Month = g.Key.Month.ToString(),
                    Year = g.Key.Year.ToString(),
                    GetYear = null,
                    Total = g.Count()
                })
                .OrderByDescending(a => a.GetYear)
                .ThenByDescending(a => a.Month)
                .ToList();


            return PartialView(model);
        }

        public PartialViewResult _TagsCloudWidget()
        {
            var alltags = _db2.SelectAll();
            return PartialView(alltags.Take(Properties.Settings.Default.TagsCloudWidget));
        }

        public PartialViewResult _HeaderLinksWidget()
        {
            ViewBag.About = Properties.Settings.Default.BlogUrl + Properties.Settings.Default.AboutPageUrl;
            ViewBag.Contact = Properties.Settings.Default.BlogUrl + Properties.Settings.Default.ContactPageUrl;
            ViewBag.BlogHome = Properties.Settings.Default.BlogUrl;

            return PartialView();
        }

        public PartialViewResult _HeaderWidget()
        {
            ViewBag.Title = Properties.Settings.Default.Title;
            ViewBag.Description = Properties.Settings.Default.Description;
            ViewBag.BlogHome = Properties.Settings.Default.BlogUrl;

            return PartialView();
        }
    }
}

//// Monthly Archive
//// Original shit wirtten by some American fat ass
//public PartialViewResult _MonthlyArchiveWidget()
//{
////   give me a `db` here

//    var model = db.Articles
//        .GroupBy(o => new
//        {
//            Month = o.ArticleCreated.Value.Month,
//            Year = o.ArticleCreated.Value.Year
//        })
//        .Select(g => new ArchiveArticles
//        {
//            Month = g.Key.Month,
//            Year = g.Key.Year,
//            Total = g.Count()
//        })
//        .OrderByDescending(a => a.Year)
//        .ThenByDescending(a => a.Month)
//        .ToList();


//    return PartialView(model);
//}
