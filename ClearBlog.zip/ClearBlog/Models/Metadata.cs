﻿using System.Web.Mvc;

namespace ClearBlog.Models
{
    public class ArticleMetadata
    {
        [AllowHtml]
        public string ArticleContent { get; set; }
    }

    public class PageMetadata
    {
        [AllowHtml]
        public string PageContent { get; set; }
    }
}