﻿using System.ComponentModel.DataAnnotations;

namespace ClearBlog.Models
{
    [MetadataType(typeof(ArticleMetadata))]
    public partial class Article
    {
    }

    [MetadataType(typeof(PageMetadata))]
    public partial class Page
    {
    }
}