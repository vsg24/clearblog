﻿using System;
using ClearBlog.Helpers;
using ClearBlog.Properties;

namespace ClearBlog.Models.ViewModels
{
    public class ArchiveArticles
    {
        public string Year { get; set; }
        public string Month { get; set; }
        public string MonthName
        {
            get
            {
                DateTime dt = new DateTime(2000, int.Parse(this.Month), 20);

                if (ClearBlog.Areas.Admin.Controllers.AdminHomeController.Language() == "en-US")
                {
                    return dt.ToString("MMMM");
                }
                else if (ClearBlog.Areas.Admin.Controllers.AdminHomeController.Language() == "fa-IR")
                {
                    return dt.ToPeString("MMM");
                }
                return null;
            }
        }

        public string GetYear
        {
            get
            {
                var intmonth = int.Parse(Month);
                DateTime dt = new DateTime(int.Parse(Year), intmonth, 20);

                if (ClearBlog.Areas.Admin.Controllers.AdminHomeController.Language() == "en-US")
                {
                    return dt.ToString("yyyy");
                }
                else if (ClearBlog.Areas.Admin.Controllers.AdminHomeController.Language() == "fa-IR")
                {
                    return dt.ToPeString("yyyy");
                }
                return null;
            }
            set {} // Just to shut the compiler up
        }
        public int Total { get; set; }
    }
}