﻿using System.ComponentModel.DataAnnotations;

namespace ClearBlog.Models.ViewModels
{
    public class UserViewModel
    {
        public int UserID { get; set; }
        [Display(Name = "UserName", ResourceType = typeof(Resources.Global))]
        public string UserName { get; set; }
        [Display(Name = "FullName", ResourceType = typeof(Resources.Global))]
        public string FullName { get; set; }
        [Display(Name = "Email", ResourceType = typeof(Resources.Global))]
        public string Email { get; set; }
        [Display(Name = "Password", ResourceType = typeof(Resources.Global))]
        public string PasswordHash { get; set; }
        [Display(Name = "Avatar", ResourceType = typeof(Resources.Global))]
        public string Avatar { get; set; }
    }
}