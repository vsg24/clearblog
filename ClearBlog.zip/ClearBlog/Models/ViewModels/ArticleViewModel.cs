﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ClearBlog.Helpers;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using ClearBlog.Controllers;
using ClearBlog.IRepository;

namespace ClearBlog.Models.ViewModels
{
    public class ArticleViewModel
    {
        public int ArticleID { get; set; }
        [Display(Name = "Title", ResourceType = typeof(Resources.Global))]
        public string ArticleTitle { get; set; }
        [Display(Name = "Content", ResourceType = typeof(Resources.Global))]
        public string ArticleContent { get; set; }
        [Display(Name = "UrlSlug", ResourceType = typeof(Resources.Global))]
        public string UrlSlug { get; set; }
        [Display(Name = "ArticleStatus", ResourceType = typeof(Resources.Global))]
        public string ArticleStatus { get; set; }
        [Display(Name = "Created", ResourceType = typeof(Resources.Global))]
        public Nullable<System.DateTime> ArticleCreated { get; set; }
        [Display(Name = "Updated", ResourceType = typeof(Resources.Global))]
        public Nullable<System.DateTime> ArticleUpdated { get; set; }
        [Display(Name = "MetaKeywords", ResourceType = typeof(Resources.Global))]
        public string MetaKeywords { get; set; }
        [Display(Name = "MetaDescription", ResourceType = typeof(Resources.Global))]
        public string MetaDescription { get; set; }
        public Nullable<int> ArticleAuthorID { get; set; }

        public string ArticleDateTimeFormatted
        {
            get
            {
                return ArticleCreated.Value.ToPeString("dd MMMM yyyy");
            }
        }

        public virtual User User { get; set; }
        [Display(Name = "Tags", ResourceType = typeof(Resources.Global))]
        public List<Tag> Tags { get; set; }
        public string CommentCount { get; set; }

        [Display(Name = "Author", ResourceType = typeof(Resources.Global))]
        public string ArticleAuthorUser
        {
            get { return User.UserName; }
        }

        public string ArticleStatusString 
        {
            get
            {
                switch (ArticleStatus)
                {
                    case "Pending":
                        return Resources.Global.Pending;
                    case "Published":
                        return Resources.Global.Published;
                    case "Draft":
                        return Resources.Global.Draft;
                    case "Deleted":
                        return Resources.Global.Deleted;
                    default:
                        return Resources.Global.Pending;
                }
            }
        }

        public string ArticleColor
        {
            get
            {
                switch (ArticleStatus)
                {
                    case "Pending":
                        return "warning";
                    case "Published":
                        return "success";
                    case "Draft":
                        return "default";
                    case "Deleted":
                        return "danger";
                    default:
                        return "warning";
                }
            }
        }
    }

    public class CommentViewModel
    {
        public int CommentID { get; set; }
        [Display(Name = "Author", ResourceType = typeof(Resources.Global))]
        public string CommentAuthor { get; set; }
        [Display(Name = "Comment", ResourceType = typeof(Resources.Global))]
        public string CommentContent { get; set; }
        public string CommentStatus { get; set; }
        public Nullable<System.DateTime> CommentDateTime { get; set; }
        public Nullable<int> ArticleID { get; set; }
        public Nullable<int> ResponseTo { get; set; }


        public string CommentStatusString
        {
            get
            {
                switch (CommentStatus)
                {
                    case "Pending":
                        return Resources.Global.Pending;
                    case "Approved":
                        return Resources.Global.Approved;
                    case "Rejected":
                        return Resources.Global.Rejected;
                    default:
                        return Resources.Global.Pending;
                }
            }
        }

        public string CommentColor
        {
            get
            {
                switch (CommentStatus)
                {
                    case "Pending":
                        return "warning";
                    case "Approved":
                        return "success";
                    case "Rejected":
                        return "danger";
                    default:
                        return "warning";
                }
            }
        }

        public CommentViewModel()
        {
            this.CommentDateTime = DateTime.Now;
        }
    }
}